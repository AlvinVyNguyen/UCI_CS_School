#include <iostream>
#include "Coins.h"
using namespace std;

int main()
{
	Coins myCoins(0,0,0,0);
	cout << "Menu" << endl;
    	cout << "1. Deposite Change " << endl;
    	cout << "2. Extract Change " << endl;
    	cout << "3. Display balance " << endl;
	while (1)
	{
		cout << "Input options 1-3 or 4 to exit: " << endl;
		int input;
		cin >> input;
		switch(input)
		{
			case 1:
			{
				int p;
				int n;
				int d;
				int q;
				
				cout << "Enter the amount of pennies: ";
				cin >> p;
				cout << "Enter the amount of nickels: ";
				cin >> n;
				cout << "Enter the amount of dimes: ";
				cin >> d;
				cout << "Enter the amount of quarters: ";
				cin >> q;
				Coins deposit_change(q,d,n,p);
				myCoins.deposit_coins(deposit_change);
				break;
			}

			case 2:
			{
				int extract;
				cout << "Enter amount to extract: ";
				cin >> extract;
				myCoins.extract_exact_change(extract);
				break;
			}
				
			case 3:
			{
				cout << "Your balance is: " << myCoins << endl;
				break;
			}

			case 4:
			{
				cout << "Done" << endl;
				return 0;
			}
			default:
			{
				cout << "Invalid Command" << endl;
			}
		}
	}
	return 0;
}

