#include "Coins.h"
using namespace std;

const int CHIPS = 68;
const int PIGGY = 205;
int main ()
{
	Coins pocket(5,3,6,8);
	Coins piggyBank(50,50,50,50);
	cout << "I started with " << pocket << " in my pocket " << endl;
	cout << "I take out 68 cents from my pocket to buy a bag of chips" << endl;
	pocket.extract_exact_change(CHIPS);
	cout << "I bought a bag of chips for 68 cents and now I have " << pocket << " left in my pocket" << endl;
	cout << "I transfer " << PIGGY << " cents to my pocket from my piggybank" << endl;
	Coins twohundredfive(8,0,1,0);
	pocket.deposit_coins(twohundredfive);
	piggyBank.extract_exact_change(PIGGY);
	cout << "I now have this much change in my pocket " << pocket << " and this much in my piggybank " << piggyBank << endl;
	Coins sofa(10,10,10,10);
	piggyBank.deposit_coins(sofa);
	cout << "I have found change from my sofa and deposited into my piggybank, I now have " << "$22.55" << " in my piggyBank " << endl;
	return 0;
}
