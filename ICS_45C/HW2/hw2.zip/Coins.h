#include <iostream>
using namespace std;
const int CENTS_PER_QUARTER = 25, CENTS_PER_DIME = 10,
CENTS_PER_NICKEL = 5;
class Coins
{
	public:
		Coins( int q, int d, int n, int p );
		void deposit_coins ( Coins & c ); // Remove coins from c and put them into this Coins object
		bool has_exact_change_for_cents ( int amount_in_cents );
		Coins extract_exact_change( int amount_in_cents );
		int total_value_in_cents();
		void print( ostream & out ); // "6 quarters, 2 dims, etc"
	private:
		int quarters, dimes, nickels, pennies;
};
	Coins::Coins( int q, int d, int n, int p)
	{
		quarters = q;
		dimes = d;
		nickels = n;
		pennies = p;
	}

	bool Coins::has_exact_change_for_cents ( int amount_in_cents )
	{
		return amount_in_cents <= ((CENTS_PER_NICKEL * nickels) + (CENTS_PER_DIME * dimes) +
		(CENTS_PER_QUARTER * quarters) + pennies);

	}
		
	void Coins::deposit_coins(Coins & c)
	{
		pennies += c.pennies;
		c.pennies = 0;
		
		nickels += c.nickels;
		c.nickels = 0;
		
		dimes += c.dimes;
		c.dimes = 0;
		
		quarters += c.quarters;
		c.quarters = 0;
	}

	Coins Coins::extract_exact_change( int amount_in_cents )
	{
		int number_of_nickels;
		int number_of_dimes;
		int number_of_quarters;
		int remainder = amount_in_cents;
		int test = has_exact_change_for_cents(amount_in_cents);
		if (test == 1)
		{

			number_of_nickels = nickels - (remainder/CENTS_PER_NICKEL);
			if (number_of_nickels<0)
			{
				number_of_nickels = nickels;
			}
			
			else
			{
				number_of_nickels = (remainder/CENTS_PER_NICKEL);
			}

			number_of_dimes = dimes - (remainder/CENTS_PER_DIME);
			if (number_of_dimes<0)
			{
				number_of_dimes = dimes;
			}
			
			else
			{
				number_of_dimes = (remainder/CENTS_PER_DIME);
			}


			number_of_quarters = quarters - (remainder/CENTS_PER_QUARTER);
			if (number_of_quarters<0)
			{
				number_of_quarters = quarters;
			}
			
			else
			{
				number_of_quarters = (remainder/CENTS_PER_QUARTER);
			}
			pennies = pennies - remainder; nickels = nickels - number_of_nickels;
			dimes = dimes - number_of_dimes; quarters = quarters - number_of_quarters;
			return Coins(number_of_quarters,number_of_dimes,number_of_nickels,remainder);
		}
	}

	int Coins::total_value_in_cents()
	{
		int total_value_in_cents = 0;
		total_value_in_cents = (CENTS_PER_NICKEL * nickels) + (CENTS_PER_DIME * dimes) +
		(CENTS_PER_QUARTER * quarters) + pennies;
		return total_value_in_cents;
	}

	void Coins::print(ostream & out)
	{
		out << quarters << " quarters, " << dimes << " dimes, " << nickels << " nickels, " <<
		pennies << " pennies";
	}

	ostream & operator << ( ostream & out, Coins c )
	{
		c.print(out);
		return out;
	}	



