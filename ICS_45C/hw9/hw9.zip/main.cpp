#include <string>
#include <algorithm>
#include <map>
#include <set>
#include <iostream>
#include <fstream>
#include <iterator>
#include "SetList.h"
#include "MapArray.h"
using namespace std;

int main()
{
	SetList < string > SL; MapArray < int> MA;
	set< string > S; map< string, int > M; 
	ifstream in_stop( "stopwords.txt" ); 
	ifstream in_sample( "sample_doc.txt" ); 
	ofstream out_freq( "frequency.txt" );
		for_each( istream_iterator< string > ( in_sample),
			istream_iterator< string > (),
			[&] ( string a )
			{
			});
		for_each( begin( MA ), end( MA ),
			[&] ( pair<string,int> pa )
			{
			});
		for_each( istream_iterator< string > ( in_sample),
			istream_iterator< string > (),
			[&] ( string s )
			{
				transform( s.begin(), s.end(), s.begin(), ::tolower );
				if( S.find( s ) == S.end() ) M[s]++;
			} );
		for_each( begin( M ), end( M ),
			[&] ( pair<string,int> p )
			{
				out_freq << p.first << ": " << p.second << "\n";
			} );
		copy( istream_iterator< string > ( in_stop ),
			istream_iterator< string > (),
			inserter( S, begin(S) ) );
	return 0;
}