#include <iostream>
#include <vector>
#include <algorithm>
#include <iterator>
using namespace std;

template
    <typename T>
class MapArray
{
    T* buf;
    int sz;
public:
    struct iterator
    {
        typedef std::forward_iterator_tag iterator_category;
        typedef iterator self_type;
        typedef T value_type;
        typedef T& reference;
        typedef T* pointer;
        typedef ptrdiff_t difference_type;
    private:
        pointer ibuf;
    public:
        iterator(pointer ptr) : ibuf(ptr) { }
        self_type operator++() { ++ibuf; return *this; }
        self_type operator++(int postfix) { self_type cpy = *this; ibuf++; return cpy; }
        reference operator*() { return *ibuf; }
        pointer operator->() { return ibuf; }
        bool operator==(const self_type& rhs) const { return ibuf == rhs.ibuf; }
        bool operator!=(const self_type& rhs) const { return ibuf != rhs.ibuf; }
    };

    struct const_iterator
    {
        typedef std::forward_iterator_tag iterator_category;
        typedef const_iterator self_type;
        typedef T value_type;
        typedef T& reference;
        typedef T* pointer;
        typedef ptrdiff_t difference_type;
    private:
        pointer buf;
    public:
        const_iterator(pointer ptr) : buf(ptr) { }
        self_type operator++() { ++buf; return *this; }
        self_type operator++(int postfix) { self_type cpy = *this; buf++; return cpy; }
        const reference operator*() { return *buf; }
        const pointer operator->() { return buf; }
        bool operator==(const self_type& rhs) const { return buf == rhs.buf; }
        bool operator!=(const self_type& rhs) const { return buf != rhs.buf; }
    };

    ~MapArray() { delete[] buf; }
};