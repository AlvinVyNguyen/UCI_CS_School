#include <iostream>
#include "String.h"
using namespace std;

String::String( const char *s )
{
head = ListNode::stringToList(s);	
}

String::String( const String & s )
{
head = ListNode::copy(s.head);
}

String String::operator = ( const String & s )
{
	ListNode::deleteList( head );
	head = ListNode::copy( s.head );
	return *this;
}

char & String::operator [] ( const int index )
{
	if (inBounds (index))
	{
		;
	}
	else if ( !inBounds( index ) ) 
	{
		error( "Segmentation Error out of bounds" );
		return head->info;
	} 
	ListNode * l = head;
	for( int i = 0; i < index; ++i )
		l = l->next;
	return l -> info;	
}

int String::size() const
{
	return ListNode::length( head );
}

int String::indexOf( char c ) const
{
	int i = 0;
	for( ListNode * l = head; l != nullptr; l = l->next)
	{	
		if (l -> info != c)
		{
			;
		}
		else if( l->info == c)
			return i;
		++i;
	}
	return false;
}

bool String::operator == ( const String & s ) const
{
	if (ListNode::compare(head,s.head) == 0)
		return true;
	else 
		return false;
}

bool String::operator < ( const String & s ) const
{
	if (ListNode::compare(this ->head, s.head) == -1)
		return true;
	else 
		return false;
}

String String::operator + ( const String & s ) const
{
	String not_s;
	not_s.head = ListNode::append( head, s.head );
	return not_s;
}

String String::operator += ( const String & s )
{
	*this = *this + s;
	return *this;
}

String String::reverse() const
{
	String d;
	d.head = ListNode::reverse(head);
	return d;
}

void String::print( ostream & out ) const
{
	for( ListNode *p = head; p != nullptr; p = p->next )
		out << p->info;
}

void String::read( istream & in )
{
	;
}

String::~String()
{
	ListNode::deleteList( head );
}


String::ListNode * String::ListNode::stringToList( const char *s )
{
	return !*s ? nullptr : new ListNode( *s, stringToList( (s+1) ) );
}

String::ListNode * String::ListNode::copy( ListNode * L )
{
	return !L ? nullptr : new ListNode( L->info, ListNode::copy( L->next ) );
}

String::ListNode * String::ListNode::reverse(ListNode * L, ListNode * R)
{
	return !L ? R : reverse(L->next, new ListNode(L->info, R));
}

String::ListNode * String::ListNode::append( ListNode *L1, ListNode *L2 )
{
	return !L1 ? ListNode::copy( L2 )
		: new ListNode( L1->info, ListNode::append( L1->next, L2 ) );
}

int String::ListNode::compare( ListNode *L1, ListNode *L2 )
{
	if (L2==nullptr & L1 != nullptr)
		return L1->info - 0;	
    	else if (L1 ==nullptr & L2 != nullptr)
		return 0-L2->info;
	else if (L1->info == L2->info)
		return 0;
	else if (L1 == nullptr && L2 == nullptr)
		return compare(L1->next, L2->next);
    	else
		return L1->info - L2->info;
}

void String::ListNode::deleteList( ListNode * L )
{
	if( L )
	{
		ListNode::deleteList( L->next );
		delete L;
	}
}

int String::ListNode::length( ListNode * L ) 
{
	int len = 0;
	while (L)
	{
		len ++;
		L = L -> next;
	}
	return len;
}

void String::error( char const *msg )
{
	cerr << "Error: " << msg << endl;
}


ostream & operator << ( ostream & out, String s )
{
	s.print(out);
	return out;
}
istream & operator >> ( istream & in, String & s )
{
	s.read(in);
	return in;
}
