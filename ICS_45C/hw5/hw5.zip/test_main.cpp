#include "String.h"

void test_constructor_and_print()
{
cout << "Testing Constructor and Print" << endl;
String a("Hello");
cout << "String a(Hello)" << endl;
String b("Test1");
cout << "String b(Test1)" << endl;
String c("Test2");
cout << "String c(Test2)" << endl;
cout << a << endl << b << endl << c << endl << endl;
}

void test_operator_assignment()
{
	cout << "Testing Assignment Operator =" << endl;
	String test("Assigned");
	String test1("Assigned twice");
	String test2("Assigned three times");
	cout << "String test" << endl << "String test1"<< endl << "String test2" << endl<< "test = Assigned" << endl 
	<< "test1 = Assigned twice" << endl << "test2 = Assigned three times" << endl;
	cout << test << endl << test1 << endl << test2 << endl << endl;
}

void test_operator_index()
{
	cout << "Testing Operator Index []" << endl;
	String test("Hello");
	cout << "String test = Hello" << endl;
	cout << "test[0]: " << test[0] << endl;
	cout << "test[1]: " << test[1] << endl;
	cout << "test[4]: " << test[4] << endl << endl;

}

void test_size()
{
	cout << "Testing Size" << endl;
	String test("abcdefg");
	cout << "String test = abcdefg" << endl;
	cout << test.size() << endl;
	String test1("weflkwjeafl");
	cout << "String test1 = weflkwjeafl" << endl;
	cout << test1.size() << endl;
	String test2("werwlafhlasehflawfh");
	cout << "String test2 = werwlafhlasehflawfh" << endl;
	cout << test2.size() << endl << endl;
}

void test_boolean_functions()
{
	cout << "Testing Boolean Functions" << endl << endl;
	String correct("Hello");
	cout << "String correct = Hello" << endl;
	String wrong("Helllo");
	cout << "String wrong = Helllo" << endl;
	String correct_copy("Hello");
	cout << "String correct_copy = Hello" << endl;
	String length_seven("abcdefgh");
	cout << "String length_seven = abcdefgh" << endl << endl;

	cout << "Testing Operator ==" << endl;
	cout << "correct == wrong" << endl;
	if(correct == wrong)
		cout << "True" << endl;
	else
		cout << "False" << endl;
	cout << "correct == correct_copy" << endl;
	if(correct == correct_copy)
		cout << "True" << endl;
	else
		cout << "False" << endl;
	cout << "correct == length_seven" << endl;
	if(correct == length_seven)
		cout << "True" << endl << endl;
	else
		cout << "False" << endl << endl;

	
	cout << "Testing Operator <" << endl;
	cout << "correct < wrong" << endl;
	if(correct < wrong)
		cout << "True" << endl;
	else
		cout << "False" << endl;
	cout << "correct < correct_copy" << endl;
	if(correct < correct_copy)
		cout << "True" << endl;
	else
		cout << "False" << endl;
	cout << "correct < length_seven" << endl;
	if(correct < length_seven)
		cout << "True" << endl << endl;
	else
		cout << "False" << endl << endl;

}

void test_indexOf()
{
	cout << "Testing indexOf(char c)" << endl;
	String test("Hello");
	cout << "String test = Hello" << endl;
	cout << "test.indexOf(H): " << test.indexOf('H') << endl;
	cout << "test.indexOf(e): " << test.indexOf('e') << endl;
	cout << "test.indexOf(o): " << test.indexOf('l') << endl << endl;
}


void test_operators_shorthand_addition_and_addition()
{
	String a("a");
	String b("b");
	String cat("cat");
	String dog("dog");
	cout << "Testing Operator +" << endl;
	cout << "String a = a" << endl << "String b = b" << endl;
	cout << "a + b = " << (a + b) << endl;
	cout << "String a is: " << a << endl;
	cout << "String b is: " << b << endl;
	cout << "cat + dog = " << (cat + dog) << endl;
	cout << "String cat is: " << cat << endl;
	cout << "String dog is: " << dog << endl << endl;

	cout << "Testing Operator +=" << endl;
	cout << "a += b = " << (a += b) << endl;
	cout << "String a is: " << a << endl;
	cout << "String b is: " << b << endl;
	cout << "cat += dog = " << (cat += dog) << endl;
	cout << "String cat is: " << cat << endl;
	cout << "String dog is: " << dog << endl << endl;

}

void test_reverse()
{
	cout << "Testing Reverse" << endl;
	String test("Hello");
	String test2("World");
	String test3("abcdefghjkil");
	String reverse_test = test.reverse();
	String reverse_test2 = test2.reverse();
	String reverse_test3 = test3.reverse();
	cout << "Hello.reverse: " << reverse_test << endl;
	cout << "World.reverse: " << reverse_test2 << endl;
	cout << "abcdefghjkil.reverse: " << reverse_test3 << endl << endl;
}


int main()
{

	test_constructor_and_print();
	test_operator_assignment();
	test_operator_index();
	test_size();
	test_boolean_functions();
	test_indexOf();
	test_operators_shorthand_addition_and_addition();
	test_reverse();

}


