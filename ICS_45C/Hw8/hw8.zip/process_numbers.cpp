#include <algorithm>
#include <vector>
#include <iostream>
#include <fstream>
#include <iterator>
using namespace std;

int main()
{
	vector< int > Number_vector;
	ofstream odd( "odd.txt" );
	ofstream even( "even.txt" );
	ifstream num( "rand_numbers.txt" );
		copy( istream_iterator< int > ( num ),
			istream_iterator< int > (),
			back_inserter( Number_vector ) );
	sort( begin( Number_vector), end( Number_vector ) );
		for_each( begin(Number_vector), end(Number_vector), [&](int i)
			{
				if( i%2 != 0 )
				{
				 odd << i << " ";
				}
				else 
				{
				 even << i << "\n";
				}
			} );
	return 0;
}

