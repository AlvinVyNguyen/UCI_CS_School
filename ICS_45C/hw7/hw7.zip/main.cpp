#include <iostream>
#include "Matrix.h"
using namespace std;

template
	< typename T >
void fillMatrix( Matrix <T> & m )
{
  int i, j;
  for ( i = 0; i < m.numRows(); i++ )
    m[i][0] = T();
  for ( j = 0; j < m.numCols(); j++ )
    m[0][j] = T();
  for ( i = 1; i < m.numRows(); i++ )
    for ( j = 1; j < m.numCols(); j++ )
    {
      m[i][j] = T(i * j);
    }
}
void test_int_matrix()
{ // here is a start, but make it better
    Matrix < int > m(10,5);
    fillMatrix( m );
    cout << m;
}
void test_double_matrix()
{ // here is a start, but make it better
	   Matrix < double > M(8,10);
    fillMatrix( M );
    cout << M;
}
void generate_exception( Matrix < double > &m )
{
    int a;
    int b;
          for ( a = 0; a < 50; a++ )
    {
          for ( b = 0; b < 50; b++ )
          {
                cout << m[a][b];
          }
          cout << endl;
    }
}
void test_double_matrix_exceptions()
{
	try
	{
    		// PUT YOUR TRY/CATCH AROUND THE INSTRUCTIONS BELOW
    		cout << "Starting...\n";
    		Matrix < double > M(8,10);
    		fillMatrix( M );
    		cout << M;
    		generate_exception( M );
	}
	catch (IndexOutOfBoundsException & e)
	{
		cout << endl << "This is out of bounds" << endl;
	}
    	cout << "Done\n";
}

int main()
{
   for ( int i=0; i<3; ++i)
   {
   test_int_matrix();
   test_double_matrix();
   test_double_matrix_exceptions();
   }
   return 0;
}
