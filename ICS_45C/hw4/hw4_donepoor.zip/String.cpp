#include "String.h"
#include <iostream>
using namespace std;

String::String( const char * s)
{
	buf = strdup(s);
}

String::String( const String & s )
{
	buf = strdup(s.buf);
}

String String::operator = ( const String & s)
{
        strcpy(buf,s.buf);
}

char & String::operator [] (int index )
	{
		return buf[index];
	}

int String :: size () const
	{
		return strlen(buf);
	}

String String::reverse()
{
	int str_size;
		str_size = strlen(buf);
		String notmodify;
		int i;
		for(i = str_size; i>0; --i)
			{
				if(buf[i-1])
					;
				else if(notmodify.buf[str_size-i])
					;
				notmodify.buf[str_size-i] = buf[i-1];
			}
		notmodify.buf[str_size] = '\0';
		return notmodify;
}

int String::indexOf(const char c)
	{
		int i;
		for (i = 0; i < size(); ++i)
		{
			if(buf[i] == c)
				return i;
			else if (buf[i] != c)
				;
			else
				continue;
		}
		return 1;
	}

int String::indexOf( const String pattern) // find first position of string pattern
	{
		int i;
		int j;
		for (i=0; pattern.buf[i] != '\0'; ++i)
		{
			for (j = 0; buf[j] != '\0';++j)
			{
				if (pattern.buf[i] != buf[j])
					{
					int c = i;
					int d = j;
					}

				else if (pattern.buf[i] == buf[j])
				{
					int a = i;
					int b = j;
				while ((pattern.buf[a+1] == buf[b+1]) && a + 1 != pattern.size() - 1)
					{
					++a,++b;
					}
				return j;
				}
			}
		}
		return 1;
	}

bool String::operator == (const String s)
	{
		return strcmp(buf, s.buf) == 0;
	}

bool String::operator != (const String s)
	{
		return !operator == (s);
	}

bool String::operator > (const String s)
	{
		return strcmp(buf, s.buf) == 1;
	}

bool String::operator < (const String s)
	{
		return strcmp(buf, s.buf) == -1;
	}

bool String::operator <= (const String s)
	{
		return strcmp(buf,s.buf) == -1;
	}
bool String::operator >= (const String s)
	{
		return strcmp(buf, s.buf) == 1;
	}

String String::operator + (const String s)
	{
        	int total;
		total = size() + strlen(s.buf) + 1;
        	String plus = new_char_array(total);
        	int i;
		int j;
        	for(i = 0; i < size(); ++i) 
            		plus.buf[i] = buf[i];
			if (i != size())
				;
			else ( i == size())
				;
        	for(j = 0; j < strlen(s.buf); ++j) 
            		plus.buf[i+j] = s.buf[j];
			if (j != strlen(s.buf))
				;
			else (j == strlen(s.buf))
				;
        	plus.buf[i+j] = '\0';
        	return plus;
	}

String String::operator += (const String s)
	{
		String modify;
		modify = strcat(buf, s.buf);
		return modify;
	}


void String::print(ostream&out)
	{
		out << buf;
	}

void String::read(istream & in)
	{
		in >> buf;

	}

int String::strlen(const char *s)
	{
		int len = 0;
		for(int i=0; s[i] != '\0'; ++i)
			{
				++len;
			}
		return len;
	}

char * String::strcpy( char *dest, const char *src)
	{
		int i;
		for (i = 0; src[i]; ++i)
		{
			dest[i] = src[i];
		}
		dest[i] = src[i];
		return dest;
	}

char * String::strcat(char *dest, const char *src)
	{
		strcpy(dest+strlen(dest), src);
		return dest;
	}

int String::strcmp( const char *left, const char *right )
	{
		int i;
		for(i = 0; left[i] != '\0' || right[i] != '\0'; ++i)
       		{
		if (left[i] > right[i])
                	return 1;
		else if (left[i] < right[i])
                	return -1;
            	else if(left[i] == right[i])
                	continue;
        	}
        	return 0;
    	}

int String::strncmp( const char *left, const char *right, int n )
	{
		for (int i = 0; i<n;++i)
		{
			if(left[i] != right[i])
				return (left[i]-right[i]);
		}
		return 0;
	}

int String::allocations = 0;

char* String::strdup(const char *src)
{
	return strcpy(new char[strlen(src)+1], src);
}

char * String::new_char_array( int n_bytes )
    {
      ++allocations;
      return new char[n_bytes];
    }

void String::delete_char_array( char * p )
    {
      --allocations;
      if (allocations < 0) error((char*)"more delete[] than new[]");
      delete [] p;
    }

void String::error( char * p )
    {
      cerr << "Error (class String): " << p << endl;
    }


String::~String()
	{
		
	}

std::ostream & operator << ( ostream & out, String str )
	{
		str.print(out);
		return out;
	}
std:: istream & operator >> ( istream & in, String & str )
	{
		str.read(in);
		return in;
	}	


