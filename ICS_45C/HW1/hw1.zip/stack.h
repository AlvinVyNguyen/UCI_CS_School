#define STACK_CAPACITY 1000
#include<iostream>
using namespace std;
  class Stack
  {
  private:
 	 int count;
 	 int stk[STACK_CAPACITY];
 	 void error(const char * msg)
	{
		cout << "ERROR" << msg << endl;
		return;
	} 
  public:
   	 Stack()  // constructor for a stack
	 {
		count = 0;
	 }
   	 void push( char c ) // adds c to the top of the stack
	{ 
		if (isFull())
		{
			error("Stack is full");
			return;
		}
		stk[count++] = c;
	}
   	 char pop() // removes top element, returns it
	{
		if (isEmpty())
		{
			error("Stack is empty");
			return 'A';
		}
		return stk[--count];
	}
   	 char top() // returns the top element, w/o removing
	{
		if (isEmpty())
		{
			error("Stack is empty cannot top");
			return 'B';
		}
		return stk[count-1];
	}
   	 bool isEmpty() // returns true iff the stack is empty
	{
		return count <= 0;
	}
   	 bool isFull() // returns true iff the stack is full
	{
		return count == STACK_CAPACITY;
	}
   	 ~Stack(); // destructor for a stack
  };
