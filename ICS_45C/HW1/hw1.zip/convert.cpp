#include <iostream>
using namespace std;
double convert(int knot)
{
	return knot*0.01917966;
}

int main()
{
	int i;
	cin >> i;
	double value = convert(i);
	cout << value << endl;
	return 0;
}
