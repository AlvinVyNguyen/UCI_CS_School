#include<iostream>
#include "stack.h"
using namespace std;

int main()
{
	//std:stack.h<int> stack1;
	//while (!stack1.isEmpty())
	{
		//std:stack.h<char> getline(cin,str);
	//	cout << stack.pop();
		return 0;
	}
}
